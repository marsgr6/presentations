# Module with functions to simulate coin tossing

import random as r

def lanzar_N_Veces(n):
	"""
	Devuelve un vector binario de longitud n
	con valores 1: cara, 0:cruz 
	Ejemplo para n = 10
	[0, 1, 0, 1, 1, 0, 0, 0, 1, 1]
	El vector devuelto es generado aleatoriamente
	use random o randint
	"""
	pass

def contarCaras(M):
	"""
	Devuelve la proporcion de 1s (caras) en
	el vector M
	Para el ejemplo anterior 
	[0, 1, 0, 1, 1, 0, 0, 0, 1, 1]
	debe devolver 0.5
	"""
	pass

def main(args):
	"""
	Uso: python moneda.py <n>
	n: numero de lanzamientos
	Ejemplo: python moneda.py 100
	"""
	if len(args) != 1:
		print(main.__doc__)
	else:
		print("Proporcion de caras:")


if __name__ == "__main__":
	import sys
	main(sys.argv[1:])
