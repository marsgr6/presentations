# Module with functions to simulate coin tossing

import random as r
	

def lanzar_N_Veces2(n):
	"""
	Devuelve un vector longitud n con el resultado de la suma
	de 2 vectores binarios.
	Equivale al lanzamiento de 2 monedas 
	Valores 1: cara, 0:cruz 
	Para 2 monedas
	Valores: 2Ca = 2; 1CaCr,1CrCa,=1; 2Cr=0
	Ejemplo para n = 10, [1, 2, 2, 2, 1, 1, 1, 0, 2, 0]
	Debe generar 2 vectores binarios {0,1} independientes
	1 para cada moneda, y luego sumar los resultados
	Cada vector es de longitud n
	"""
	pass
	
	
def contarFrecuencias(M):
	"""
	Cuenta las frecuencias de cada valor en M
	Frecuencias teoricas esperadas: 0: 1/4, 1:1/2, 2:1/4
	Para el ejemplo anterior, [1, 2, 2, 2, 1, 1, 1, 0, 2, 0]
	debe devolver [0.2, 0.4, 0.4]
	"""
	pass


def main(args):
	"""
	Uso: python moneda2.py <n>
	n: numero de lanzamientos
	Ejemplo: python moneda2.py 100
	"""
	if len(args) != 1:
		print(main.__doc__)
	else:
		print("Frecuencias para [0, 1, 2]:")


if __name__ == "__main__":
	import sys
	main(sys.argv[1:])
