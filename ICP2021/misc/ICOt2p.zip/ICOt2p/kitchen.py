# Module with functions to simulate coin tossing

import random as r


def shuffleWord(p):
	"""
	Devuelve la palabra p en orden aleatorio
	Espera que p sea un string
	Haga un muestreo aleatorio sin reemplazo
	de longitud len p en la palabra p, y
	una el resultado con join
	Ejemplo: 
	Entrada 'KITCHEN' 
	Salida 'HNCTIEK'
	"""
	pass


def compareWords(p1, p2):
	"""
	Compara la ocurrencia del string p2 en p1
	usando find
	Devuelve True si la ocurrencia existe
	False en caso contrario
	Ejemplo p1='HNCTIEK', p2='KIT'
	devolvera False
	"""
	pass


def returnProbability(p1, p2, n):
	"""
	Repite n veces los pasos 1 y 2:
	1. Realiza un sampleo sin reemplazo de p1 y almacena en p1s
	(Equivale a hacer un shuffle de p1, funcion shuffleWord)
	2. Compara la ocurrencia del string p2 en p1s
	si es verdadera incrementa un contador
	3. Devuelve el valor del contador al final del bucle 
	"""
	pass


def main(args):
	"""
	Uso: python kitchen.py p1 p2 n
	p1: palabra 1
	p2: palabra 2, es subconjunto de p1
	n: numero de muestreos
	Ejemplo: python kitchen.py KITCHEN KIT 1000
	"""
	if len(args) != 3:
		print(main.__doc__)
	else:
		print("Ocurrencias: ")


if __name__ == "__main__":
	import sys
	main(sys.argv[1:])
