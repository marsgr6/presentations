# Module with functions to simulate coin tossing

import random as r
	

def lanzar_N_Veces(n):
	"""
	Devuelve un vector longitud n con el resultado de 
	lanzar 1 dado
	Valores posibles 1, 2, ..., 6 generados aleatoriamente
	Ejemplo: para n=10, [3, 3, 2, 3, 5, 1, 6, 6, 6, 3]
	"""
	pass	
	
def contarFrecuencias(M):
	"""
	Cuenta las frecuencias de cada valor en M
	Esperado: 1: 1/6, 2: 1/6, 3: 1/6, 4: 1/6, 5: 1/6, 6: 1/6
	Para el ejemplo anterior [3, 3, 2, 3, 5, 1, 6, 6, 6, 3]
	debe devolver [0.1, 0.1, 0.4, 0.0, 0.1, 0.3]
	"""
	pass


def main(args):
	"""
	Uso: python dado.py <n>
	n: numero de lanzamientos
	Ejemplo: python dado.py 100
	"""
	if len(args) != 1:
		print(main.__doc__)
	else:
		print("Frecuencias para [1, 2,..., 6]:")


if __name__ == "__main__":
	import sys
	main(sys.argv[1:])
