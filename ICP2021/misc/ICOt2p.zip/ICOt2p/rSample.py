# Module with functions to simulate coin tossing

import random as r


def leerEntrada(s):
	"""
	Lee una cadena de strings de valores numericos separados por coma
	Ej. : '994,919,815,862,1140,890'
	Separa (split) y transforma los valores en float
	Devuelve una lista numerica float:
	[994.0, 919.0, 815.0, 862.0, 1140.0, 890.0]
	"""
	pass
	
	
def muestra(V, n):
	"""
	Devuelve una muestra de longitud n tomada de la lista V
	El muestreo es con reemplazo 
	Genere numeros aleatorios entre 0 y la longitud de la
	lista-1, el valor generado equivale al indice de la 
	lista V, correspondiente al elemento que estara en la
	muestra seleccionada
	Ejemplo para n=4, [862.0, 994.0, 862.0, 862.0]
	"""
	pass
	
	
def muestraSR(V, n):
	"""
	Devuelve una muestra de longitud n tomada de la lista V
	El muestreo es sin reemplazo a partir
	de los indices devueltos por la funcion vectorSR
	Ejemplo para n=4, [862.0, 919.0, 815.0, 994.0]
	"""
	pass
	

def vectorSR(n, vi, vf):
	"""
	Devuelve un listado de n elementos unicos
	en el rango (vi, vf) ambos incluidos
	generados aleatoriamente
	Ejemplo para n=4, vi=0, vf=9
	[3, 2, 0, 9]
	El ejemplo asume que se utilizara para un
	muestreo sin reemplazo en una lista de 
	longitud 10, dado que vi y vf estan
	incluidos, se usa vi=0, vf=9
	dada la convencion de python para indices
	entre 0 y len(list)-1
	"""
	pass


def main(args):
	"""
	Uso: python rSample.py <n> <tm> <val>
	n: longitud de la muestra
	tm: tipo de muestreo, sr->sin reemplazo, cr->con reemplazo
	val: cadena de valores
	Ejemplo: python rSample.py 4 sr 994,919,815,862,1140,890
	"""
	if len(args) != 3:
		print(main.__doc__)
	else:
		if args[1]=='cr':
			# leer datos 
			print("Muestra: ")
		elif args[1]=='sr':
			# leer datos 
			print("Muestra: ")
		else:
			print("Tipo de muestreo no valido")


if __name__ == "__main__":
	import sys
	main(sys.argv[1:])
