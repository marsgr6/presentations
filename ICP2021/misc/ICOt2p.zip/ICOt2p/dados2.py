# Module with functions to simulate coin tossing

import random as r
	

def lanzar_N_Veces2(n):
	"""
	Devuelve un vector longitud n con el resultado de la suma
	de 2 dados
	Valores posibles 2,3,...,12
	Ejemplo para n=10
	[4, 4, 9, 8, 7, 9, 10, 9, 9, 11]
	Debe generar independientemente los lanzamientos
	para cada uno de los dados y sumar el resultado
	El lanzamiento de cada dado puede ser generado con 
	randint o random
	"""
	pass

	
def contarFrecuencias(M):
	"""
	Cuenta las frecuencias de cada valor en M
	Esperado: 2: 1/36, 3: 2/36, 4: 3/36, 5: 4/36, 6: 5/36
	7: 6/36, 8: 5/36, 9: 4/36, 10: 3/36, 11: 2/36, 12: 1/36 
	Para el ejemplo anterior debe devolver:
	[0.0, 0.0, 0.2, 0.0, 0.0, 0.1, 0.1, 0.4, 0.1, 0.1, 0.0]
	"""
	pass


def main(args):
	"""
	Uso: python dados2.py <n>
	n: numero de lanzamientos
	Ejemplo: python dados2.py 100
	"""
	if len(args) != 1:
		print(main.__doc__)
	else:
		print("Frecuencias para [1, 2,..., 12]:")


if __name__ == "__main__":
	import sys
	main(sys.argv[1:])
